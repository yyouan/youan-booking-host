import json
array={"id":[]}
with open('line_id.txt') as json_file:  
    array = json.load(json_file)

if(__name__ == "__main__"):
    print(array)
