#coding=utf-8
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import codecs
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import linebot
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
import urllib
import href
import sys
import keyboard

success = False
complete = False
count = 0
unopen = False


chrome_options = Options()
chrome_options.add_argument("--disable-extensions")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--headless")

def go_driver(success,key,hhref,complete,unopen):
    
    driver = webdriver.Chrome(chrome_options=chrome_options)    # 打开 Chrome 浏览器

    status="(begin):"+key
    inner_success=success
    inner_complete=complete
    inner_unopen = unopen
    press_q =False
    
    # 将刚刚复制的帖在这
    driver.get("http://host.cc.ntu.edu.tw/activities/")
    try:
        status="(login section)"
        print(status)
        driver.find_element_by_id("LinkLogin").click()
        driver.find_element_by_id("LinkLogin").click()
        driver.switch_to.frame(0)
        driver.find_element_by_id("Account").send_keys("greentree")
        driver.find_element_by_id("Password").send_keys("tree1234")
        driver.find_element_by_id("btnSubmit").click()
        '''
        status="(activity section)"
        print(status)
        driver.switch_to.default_content()
        driver.find_element_by_id("linkActList").click()
        driver.switch_to.frame(0)
        status="(find activity section)"
        print(status)
        driver.find_element_by_id("resultGrid__ct"+str(13+activity_index)+"_btnModify").click()
        status="(go into activity section)"
        print(status)
        driver.find_element_by_id("chNotice1").click()
        driver.find_element_by_id("chNotice2").click()
        driver.find_element_by_id("btnPlace").click()
        status="(place section)"
        print(status)        
        select = Select(driver.find_element_by_id("Campus"))
        select.select_by_index(campus_index)
        select = Select(driver.find_element_by_id("Build"))
        select.select_by_index(building_index)
        select = Select(driver.find_element_by_id("Floor"))
        select.select_by_index(floor_index)        
        driver.find_element_by_id("QueryPlace").click()
        status="(query room section)"
        print(status)
        ##change method
        driver.find_element_by_name("resultGrid:_ct"+str(13+room_index)+":_ctl0").click()
        '''
        status="(rent section)"
        print(status)        
        driver.get(hhref)
        driver.find_element_by_id("Use").click()
        driver.find_element_by_id("Use").clear()
        driver.find_element_by_id("Use").send_keys(u"社課")
        status="(submit section)"
        print(status)
        webElement = driver.find_element_by_id("btnSubmit")
        webElement.click()
        ccount=0
        print("(notice) [Press] q to end this program")
        while True:
            if keyboard.is_pressed('q'):
                driver.switch_to.alert.accept()
                press_q =True
                break
            try:                
                driver.switch_to.alert.accept()               
                print("unopen:"+str(ccount))
                inner_unopen =True
                msgs = [{"type":"text","text":"場地未開放，繼續訂票"}]
                if (time.localtime().tm_min % 5 == 0 and time.localtime().tm_sec == 0)or ccount==0:
                    linebot.linebot(msgs)
                webElement = driver.find_element_by_id("btnSubmit")
                webElement.click()
                ccount+=1    
            except NoAlertPresentException as exception:
                break          
        driver.get("http://host.cc.ntu.edu.tw/activities/")         
        driver.switch_to.default_content()
        driver.find_element_by_id("LinkLogin").click()
        driver.find_element_by_id("LinkLogin").click()
        driver.close()
    except NoSuchElementException as exception:
        try:
            print("---------------------------------")
            print("Element not found and test failed")
            print("(detail):"+str(exception))
            print("(status):"+status)
            print("---------------------------------")
            if status == "(submit section)":
                try:
                        driver.find_element_by_id("errorLbl")
                        inner_success = True
                        
                        if inner_unopen == True:
                            print("alreay success")
                            msgs = [{"type":"text","text":"key"+"成功訂票，結束程式"}]
                            inner_complete=True
                        else:
                            print("rent by others")
                            msgs = [{"type":"text","text":"選好的"+key+"場地被訂走了，借下一個候選"}]
                        
                        linebot.linebot(msgs)
                        
                except NoSuchElementException as exception: 
                        print("unopen")
                        inner_unopen =True
                        msgs = [{"type":"text","text":"場地未開放，繼續訂票"}]
                        if (time.localtime().tm_min % 5 == 0 and time.localtime().tm_sec == 0) or count==0:
                            linebot.linebot(msgs)
                finally:
                        driver.back()
            else:
                print("!!!!!!!(two same account are logining ,auto retry,please wait at most 20min)!!!!!!!!")
                msgs = [{"type":"text","text":"兩帳號重複登入，請等待最多20min自動修復"}]
                if (time.localtime().tm_min % 5 == 0 and time.localtime().tm_sec == 0) or count==0:
                    linebot.linebot(msgs)
            #always process
            status="(logout section)"
            print(status)
            driver.find_element_by_id("LinkLogin").click()
            driver.find_element_by_id("LinkLogin").click()
        except NoSuchElementException as exception:
            try:            
                driver.switch_to.default_content()
                driver.find_element_by_id("LinkLogin").click()
                driver.find_element_by_id("LinkLogin").click()
            except NoSuchElementException as exception:
                print("---------------------------------")
                print("Element not found and test failed")
                print("(detail):"+str(exception))
                print("(status):"+status)
                print("---------------------------------")
        finally:
            status="(close section)"
            print(status)
            driver.close()
            pass

    return [inner_success,inner_complete,inner_unopen,press_q]


    '''
    completeName = os.path.join(".", "test.html")
    file_object = codecs.open(completeName, "w", "utf-8")
    html = driver.page_source
    file_object.write(html)       # get html
    driver.get_screenshot_as_file("./img/sreenshot1.png")
    '''

    '''
        driver.find_element_by_xpath(u"(.//*[normalize-space(text()) and normalize-space(.)='< 上一週'])[1]/preceding::img[1]").click()
        driver.find_element_by_link_text("31").click()
        driver.find_element_by_name("QueryDate").click()
        driver.execute_script("var q = document.getElementsByTagName(\"a\")[4];q.href=\"placeApplyDetail.aspx?From=placeApply.aspx&Place_ID=16&Act_ID=97679&Start=18:00&End=21:30&Date=2019/4/1\";q.id=\"mywant\"")
        driver.find_element_by_id("mywant").click()
    '''


for key, hhref in href.href.items():
    count=0
    success = False
    print('press q to quit')
    press_q =False
    while not success:
        if keyboard.is_pressed('q') or press_q :
            print("[quit]")
            break
        print("(count)"+str(count))
        resul = go_driver(success,key,hhref,complete,unopen)
        success= resul[0]
        complete = resul[1]
        unopen = resul[2]
        press_q = resul[3]
        count+=1
    '''
    if complete == True:
        print("[quit]")
        break
    '''
    
if complete != True:
    if press_q == True:
        pass
    else:
        print("all are rent,click start.bat for new list")
        msgs = [{"type":"text","text":"場地訂光了，趕快找電腦click start.bat重新設定場地"}]
        linebot.linebot(msgs)


