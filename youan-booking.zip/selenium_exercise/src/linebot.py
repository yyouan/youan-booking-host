import requests
import line_id
test_line_id = "U0668ab2a77e5f0efca278d6ad91277b8"
test_msgs = [{"type":"text","text":"test"}]

def linebot(msgs):
    for ids in line_id.array["id"]:
        sendmsg(msgs,ids)    

def sendmsg(msgs,ids):
    token = "zcnUg2LETTRMkZ1M7HLL+pz2RRvlBmUazp4yVEQvh61tIPbr4RILvdMrWTu/6IUwvT20AAYLx2IWpYgQTpsnQyPrprJxb0XPJgiIBWYvdavjxf6tPePMztbOVrk1gW52orOMsjhW7IKCexDP8OWXSAdB04t89/1O/w1cDnyilFU="
    
    my_headers = {'Content-Type':  'application/json', 
              'Authorization':'Bearer ' + token}
    my_data = {"to": ids,
               'messages':msgs}
    r = requests.post('https://api.line.me/v2/bot/message/push', headers = my_headers,json = my_data)
    print("(line)"+r.text)