import json,linebot,os
print("(list)---------------------------")
ans = input("want a new list? (y/n)")
href = {}
while True:
    if ans =="y":
        print("open video to introduce how to get the link...")
        os.system("start chrome \"https://youtu.be/qjwz8PVhzOo\"")
        input("press enter if you know how to")
        while True:
            ans2 = input("Give a name for link,eg.604 (if no more room you want to add,press xxx and enter)")
            if ans2 == "xxx":
                break
            else:
                ans3 = input("input link(ctrl v for paste)")
                href[ans2]=ans3

        with open('list.txt', 'w') as outfile:  
            json.dump(href, outfile)

        break
    elif ans =="n":
        break
    else:
        pass
print("(id)---------------------------")
while True:
    ans = input("want a new id? (y/n)")

    if ans =="y":
        while True:
            ans4 = input("input the id(on LineBot,if not try input everything on LineBot)you want add (ctrl-c end the program if you say yes incidently)")            
            linebot.sendmsg(linebot.test_msgs,ans4)                   
            ans5 = input("do you receive the msg(you'll see test) in 1 min? (y/n)")
            if ans == "y":
                break
            else:
                print("Maybe the id you click is wrong,input again")

        with open('line_id.txt') as json_file:  
                array = json.load(json_file)    
        array["id"].append(ans4)
        with open('line_id.txt', 'w') as outfile:  
            json.dump(array, outfile)
        
    elif ans =="n":
        break
    else:
        pass

print("(time)---------------------------")
while True:
    ans = input("want rent for now?(y/n)")
    if ans =="y":
        hour = int(input("want rent from which hour?"))
        minute = int(input("want rent from which min?"))
        import time
        print("waiting to "+str(hour)+":"+str(minute))
        print("DO NOT close the computer and the program And CHECK computer is NO-SLEEP")
        os.system("start chrome \"https://youtu.be/UiUCeCiUMiE\"")        
        while True:            
            if time.localtime().tm_hour==hour and time.localtime().tm_min==minute:
                print("(Just the time!)---------------------")
                print(os.system("python test.py"))
            time.sleep(60)
    elif ans=="n":
        break
    else:
        pass
