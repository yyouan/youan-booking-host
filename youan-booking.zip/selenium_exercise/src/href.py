import json
href ={}
with open('list.txt') as json_file:  
    href = json.load(json_file)

if(__name__ == "__main__"):
    print(href)