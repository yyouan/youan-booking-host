from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()     # 打开 Chrome 浏览器

# 将刚刚复制的帖在这
driver.get("https://www.google.com/search?q=selenium+%E6%84%8F%E6%80%9D&rlz=1C1SQJL_zh-TWTW793TW793&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjMv5Hul_jgAhXEGKYKHTx4CnMQ_AUIDigB&biw=1280&bih=610")
html = driver.page_source
soup = BeautifulSoup(html, 'html.parser')
img_tags = soup.find_all('div',class_="mVDMnf nJGrxf")
for tag in img_tags:
  # 輸出超連結的文字
  print(tag.string)
driver.close()
